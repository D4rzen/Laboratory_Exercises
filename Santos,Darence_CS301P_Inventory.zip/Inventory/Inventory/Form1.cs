﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class frmAddProduct : Form
    {
        private string _ProductName, _Category, _MfgDate, _ExpDate, _Description;
        private int _Quantity;
        private double _SellPrice;
        BindingSource ProductsBS;
        BindingList<ProductClass> ListOfProducts;
        public string Product_Name(string name)
        {
            if (!Regex.IsMatch(name, @"^[a-zA-Z]+$"))



                try
                {

                }
                catch (Exception StringFormattException)
                {

                }
                finally
                {

                }


            return name;
        }

        public int Quantity(string qty)
        {
            if (!Regex.IsMatch(qty, @"^[0-9]"))


                try
                {

                }
                catch (Exception NumberFormattException)
                {

                }
                finally
                {

                }


            return Convert.ToInt32(qty);
        }
        public double SellingPrice(string price)
        {
            if (!Regex.IsMatch(price.ToString(), @"^(\d*\.)?\d+$"))

                try
                {

                }
                catch (Exception CurrencyFormatException)
                {

                }
                finally
                {

                }

            return Convert.ToDouble(price);
        }

        public frmAddProduct()
        {
            InitializeComponent();
            ProductsBS = new BindingSource();
            ListOfProducts = new BindingList<ProductClass>();
            ProductsBS.DataSource = ListOfProducts;
            gridViewProductList.DataSource = ProductsBS;
            gridViewProductList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }   
        private void frmAddProduct_Load(object sender, EventArgs e)
        {
            string[] ListOfProductCategory = {"Beverages", "Bread/Bakery", "Canned/Jarred Goods", "Dairy", "Frozen Goods", "Meat", "Personal Care", "Other" };
            foreach (string Category in ListOfProductCategory)
            {
                cbCategory.Items.Add(Category);
            }
        }
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            _ProductName = Product_Name(txtProductName.Text);
            _Category = cbCategory.Text;
            _MfgDate = dtPickerMfgDate.Value.ToString("yyyy-MM-dd");
            _ExpDate = dtPickerExpDate.Value.ToString("yyyy-MM-dd");
            _Description = richTxtDescription.Text;
            _Quantity = Quantity(txtQuantity.Text);
            _SellPrice = SellingPrice(txtSellPrice.Text);
            ListOfProducts.Add(new ProductClass(_ProductName, _Category, _MfgDate, _ExpDate, _SellPrice, _Quantity, _Description));
            ProductsBS.ResetBindings(false);
        }   
    }
}
public class ProductClass {
    private int _Quantity;
    private double _SellingPrice;
    private string _ProductName, _Category, _ManufacturingDate, _ExpirationDate, _Description;
    public ProductClass(string ProductName, string Category, string MfgDate, string ExpDate,
    double Price, int Quantity, string Description)
    {
        this._Quantity = Quantity;
        this._SellingPrice = Price;
        this._ProductName = ProductName;
        this._Category = Category;
        this._ManufacturingDate = MfgDate;
        this._ExpirationDate = ExpDate;
        this._Description = Description;
    }
    public string ProductName
    {
        get
        {
            return this._ProductName;
        }
        set
        {
            this._ProductName = value;
        }
    }
    public string Category
    {
        get
        {
            return this._Category;
        }
        set
        {
            this._Category = value;
        }
    }
    public string ManufacturingDate
    {
        get
        {
            return this._ManufacturingDate;
        }
        set
        {
            this._ManufacturingDate = value;
        }
    }
    public string ExpirationDate
    {
        get
        {
            return this._ExpirationDate;
        }
        set
        {
            this._ExpirationDate = value;
        }
    }
    public string Description
    {
        get
        {
            return this._Description;
        }
        set
        {
            this._Description = value;
        }
    }
    public int Quantity
    {
        get
        {
            return this._Quantity;
        }
        set
        {
            this._Quantity = value;
        }
    }
    public double SellingPrice
    {
        get
        {
            return this._SellingPrice;
        }
        set
        {
            this._SellingPrice = value;
        }
    }

    class NumberFormattException : Exception
    {
        public NumberFormattException(string Quantity) : base(Quantity) { }
    }

    class StringFormattException : Exception
    {
        public StringFormattException(string Product_Name) : base(Product_Name) { }
    }
    class CurrencyFormatException : Exception
    {
        public CurrencyFormatException(string SellingPrice) : base(SellingPrice) { }
    }
}
